# السوق الليبي | LibyanSouq

## طريقة الرفع على Vercel (بدون تثبيت أي برنامج على جهازك)

1. أنشئ حساب مجاني على github.com
2. أنشئ مستودع (Repository) جديد باسم libyansouq
3. اضغط "Add file" ثم "Upload files" واسحب كل ملفات هذا المجلد (بما فيها مجلد src) إليه
4. اضغط "Commit changes"
5. روح لـ vercel.com وسجّل دخول بحساب GitHub نفسه
6. اضغط "Add New Project" ثم اختر مستودع libyansouq
7. اضغط "Deploy" واتركه يشتغل تلقائياً (يكتشف أنه مشروع Vite بنفسه)
8. بعد دقيقة تقريباً بتحصل على رابط جاهز مثل: libyansouq.vercel.app
